_makeover_by_hs Website

HOW TO DEPLOY ON VERCEL:
1. Create a free GitHub account.
2. Upload all files from this folder to a new GitHub repository.
3. Go to vercel.com and sign in with GitHub.
4. Click Add New -> Project.
5. Import the repository.
6. Click Deploy.

This is a static HTML/CSS website, so no build settings are required.
